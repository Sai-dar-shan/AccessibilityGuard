package com.accessibilityguard.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView statusView;
    private TextView troubleView;
    private EditText extraNameInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusView = findViewById(R.id.status);
        troubleView = findViewById(R.id.trouble);
        extraNameInput = findViewById(R.id.extra_name);
        Button openButton = findViewById(R.id.btn_open);
        Button saveExtraButton = findViewById(R.id.btn_save_extra);

        openButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "Could not open Accessibility settings", Toast.LENGTH_LONG).show();
            }
        });

        saveExtraButton.setOnClickListener(v -> {
            String value = extraNameInput.getText().toString().trim();
            prefs().edit().putString(GuardService.KEY_EXTRA_NAMES, value).apply();
            Toast.makeText(this, value.isEmpty() ? "Extra protected name cleared" : "Saved", Toast.LENGTH_SHORT).show();
        });

        extraNameInput.setText(prefs().getString(GuardService.KEY_EXTRA_NAMES, ""));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(GuardService.PREFS, MODE_PRIVATE);
    }

    private void refresh() {
        boolean on = isServiceEnabled();
        statusView.setText(on ? "Status: ON" : "Status: OFF");
        statusView.setTextColor(on ? Color.rgb(0x2E, 0x7D, 0x32) : Color.rgb(0xC6, 0x28, 0x28));

        SharedPreferences p = prefs();
        int count = p.getInt(GuardService.KEY_BLOCK_COUNT, 0);
        String last = p.getString(GuardService.KEY_LAST_TEXT, "");
        StringBuilder sb = new StringBuilder();
        sb.append("Times blocked: ").append(count).append("\n\n");
        sb.append("Last Settings screen text seen:\n");
        sb.append(TextUtils.isEmpty(last) ? "(nothing seen yet)" : last);
        troubleView.setText(sb.toString());
    }

    private boolean isServiceEnabled() {
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabled != 1) return false;

            String list = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(list)) return false;

            ComponentName me = new ComponentName(this, GuardService.class);
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(list);
            while (splitter.hasNext()) {
                ComponentName cn = ComponentName.unflattenFromString(splitter.next());
                if (cn != null && cn.equals(me)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }
}
