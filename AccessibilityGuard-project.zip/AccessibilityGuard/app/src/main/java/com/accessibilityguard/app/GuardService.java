package com.accessibilityguard.app;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Watches the Settings app. If any Settings screen shows the name of a protected app
 * (this app, plus any extra names saved on the main screen), it presses Home.
 */
public class GuardService extends AccessibilityService {

    static final String PREFS = "guard_prefs";
    static final String KEY_LAST_TEXT = "last_settings_text";
    static final String KEY_BLOCK_COUNT = "times_blocked";
    static final String KEY_EXTRA_NAMES = "extra_protected_names";

    /**
     * Protected app names that are built into the code. To protect your other app
     * permanently, add its exact name here, e.g. { "Accessibility Guard", "My Blocker App" }.
     * (You can also type it on the main screen of the app instead.)
     */
    private static final String[] BUILT_IN_NAMES = { "Accessibility Guard" };

    private static final String TOAST_TEXT = "Accessibility Guard can't be turned off";
    private static final long COOLDOWN_MS = 1200;
    private static final long SCAN_DELAY_MS = 40;
    private static final int MAX_NODES = 3000;
    private static final int MAX_DEPTH = 60;
    private static final int MAX_SAVED_CHARS = 3000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scanPending = false;
    private long lastBlockAt = 0;
    private String lastSavedText = null;

    private final Runnable scanRunnable = new Runnable() {
        @Override
        public void run() {
            scanPending = false;
            try {
                scanAll();
            } catch (Throwable ignored) {
                // never let the service crash
            }
        }
    };

    /** Holds the result of one scan. */
    private static class Scan {
        final StringBuilder text = new StringBuilder();
        final String[] names;
        boolean found = false;
        boolean sawSettings = false;
        int budget = MAX_NODES;

        Scan(String[] names) {
            this.names = names;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        // Events with no package (window changes) are always worth a look.
        if (pkg != null && !isSettingsPackage(pkg)) return;
        scheduleScan(SCAN_DELAY_MS);
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        scheduleScan(SCAN_DELAY_MS);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(scanRunnable);
        super.onDestroy();
    }

    private void scheduleScan(long delayMs) {
        if (scanPending) return;
        scanPending = true;
        handler.postDelayed(scanRunnable, delayMs);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private static boolean isSettingsPackage(CharSequence pkg) {
        return pkg != null && pkg.toString().toLowerCase(Locale.ROOT).contains("settings");
    }

    private String[] protectedNames() {
        List<String> list = new ArrayList<>();
        for (String n : BUILT_IN_NAMES) {
            list.add(n.toLowerCase(Locale.ROOT));
        }
        String extra = prefs().getString(KEY_EXTRA_NAMES, "");
        if (extra != null) {
            for (String part : extra.split("[,\\n]")) {
                String p = part.trim().toLowerCase(Locale.ROOT);
                // Ignore very short entries so a typo cannot block every Settings screen.
                if (p.length() >= 3) list.add(p);
            }
        }
        return list.toArray(new String[0]);
    }

    private void scanAll() {
        Scan scan = new Scan(protectedNames());

        // 1) The active window.
        AccessibilityNodeInfo active = getRootInActiveWindow();
        if (active != null && isSettingsPackage(active.getPackageName())) {
            scan.sawSettings = true;
            collect(active, scan, 0);
        }

        // 2) Every window (split screen, pop-ups, dialogs, search overlays).
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root != null) {
                    boolean same = active != null && active.equals(root);
                    if (!same && isSettingsPackage(root.getPackageName())) {
                        scan.sawSettings = true;
                        collect(root, scan, 0);
                    }
                    safeRecycle(root);
                }
                safeRecycle(w);
            }
        }
        if (active != null) safeRecycle(active);

        // Remember the last Settings screen text (only when it changes).
        if (scan.sawSettings) {
            String screenText = scan.text.toString().trim();
            if (screenText.length() > 0 && !screenText.equals(lastSavedText)) {
                lastSavedText = screenText;
                prefs().edit().putString(KEY_LAST_TEXT, screenText).apply();
            }
        }

        if (scan.found) block();
    }

    private void collect(AccessibilityNodeInfo node, Scan scan, int depth) {
        if (node == null || scan.budget <= 0 || depth > MAX_DEPTH) return;
        scan.budget--;

        addText(node.getText(), scan);
        addText(node.getContentDescription(), scan);

        int count = node.getChildCount();
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collect(child, scan, depth + 1);
                safeRecycle(child);
            }
        }
    }

    private void addText(CharSequence cs, Scan scan) {
        if (cs == null) return;
        String t = cs.toString();
        if (t.length() == 0) return;

        if (scan.text.length() < MAX_SAVED_CHARS) {
            scan.text.append(t).append('\n');
        }
        if (!scan.found) {
            String lower = t.toLowerCase(Locale.ROOT);
            for (String name : scan.names) {
                if (lower.contains(name)) {
                    scan.found = true;
                    break;
                }
            }
        }
    }

    private void block() {
        long now = SystemClock.elapsedRealtime();
        long since = now - lastBlockAt;
        if (lastBlockAt != 0 && since < COOLDOWN_MS) {
            // Still cooling down: look again right after the cooldown ends.
            scheduleScan(COOLDOWN_MS - since + 60);
            return;
        }
        lastBlockAt = now;

        performGlobalAction(GLOBAL_ACTION_HOME);

        SharedPreferences p = prefs();
        p.edit().putInt(KEY_BLOCK_COUNT, p.getInt(KEY_BLOCK_COUNT, 0) + 1).apply();

        Toast.makeText(getApplicationContext(), TOAST_TEXT, Toast.LENGTH_SHORT).show();
    }

    @SuppressWarnings("deprecation")
    private static void safeRecycle(AccessibilityNodeInfo node) {
        try {
            node.recycle();
        } catch (Throwable ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private static void safeRecycle(AccessibilityWindowInfo window) {
        try {
            window.recycle();
        } catch (Throwable ignored) {
        }
    }
}
