ACCESSIBILITY GUARD - Android project (Java, minSdk 24, targetSdk 34, no extra libraries)

This is the full source. It has NOT been compiled into an APK yet.

HOW TO GET THE APK

Option A - Android Studio (on a PC/Mac)
  1. Install Android Studio, then File > Open and pick this folder.
  2. Wait for the Gradle sync to finish.
  3. Build > Build Bundle(s) / APK(s) > Build APK(s).
  4. The file is app/build/outputs/apk/debug/app-debug.apk (debug key, installs fine).

Option B - GitHub (no installs)
  1. Create a free GitHub account and a new private repository.
  2. Upload everything in this folder (keep the hidden .github folder).
  3. Open the Actions tab > "Build APK" > wait for the green tick (a few minutes).
  4. Open that run and download "AccessibilityGuard-debug-apk" - the .apk is inside.

PROTECTING YOUR OTHER APP
  Type its exact name (as Settings shows it) in the box on the main screen and tap Save.
  To hard-code it instead, edit BUILT_IN_NAMES in
  app/src/main/java/com/accessibilityguard/app/GuardService.java

REMOVING THE APP LATER
  While the service is ON, Settings screens that show the app's name are closed on purpose.
  To remove it you need Safe Mode, or ADB: adb uninstall com.accessibilityguard.app
